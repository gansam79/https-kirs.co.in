var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1sw5-dq._.js")
R.c("server/chunks/ssr/1y1n_next_dist_esm_build_templates_app-page_0azt-c_.js")
R.c("server/chunks/ssr/[root-of-the-server]__0nkbd7w._.js")
R.c("server/chunks/ssr/1y1n_next_dist_1sy5ntu._.js")
R.c("server/chunks/ssr/1y1n_next_dist_client_components_builtin_global-error_0acdu9d.js")
R.c("server/chunks/ssr/1zb3_https-kirs_co_in__next-internal_server_app__global-error_page_actions_1tt118x.js")
R.m(97460)
module.exports=R.m(97460).exports
