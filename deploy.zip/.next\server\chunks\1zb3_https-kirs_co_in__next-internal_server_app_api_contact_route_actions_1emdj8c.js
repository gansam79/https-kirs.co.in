module.exports=[62735,(e,o,d)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_api_contact_route_actions_1emdj8c.js.map