1:"$Sreact.fragment"
3:I[43228,["/stagging/_next/static/chunks/1janglccugc1x.js","/stagging/_next/static/chunks/1rlgxtj9is0ro.js","/stagging/_next/static/chunks/1ejk9jqq5vbjp.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"DCjz9ELxi-SDwgju_bW1h"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/;307;"}
