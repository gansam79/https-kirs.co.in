1:"$Sreact.fragment"
3:I[43228,["/_next/static/chunks/0frmf2_5roz-9.js","/_next/static/chunks/3x_vse9i6mchh.js","/_next/static/chunks/1ejk9jqq5vbjp.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"xEyfr4GY2GJqbl8ie4Kir"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/;307;"}
