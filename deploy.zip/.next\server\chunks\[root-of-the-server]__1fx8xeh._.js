module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},38978,e=>{"use strict";var t=e.i(5075),a=e.i(69692),i=e.i(25147);let r=t.default.createPool({host:process.env.DB_HOST||"193.203.184.226",user:process.env.DB_USER||"u686584126_kirsdb",password:process.env.DB_PASSWORD||"Kirs@2026Db",database:process.env.DB_NAME||"u686584126_kirsdb",waitForConnections:!0,connectionLimit:10,queueLimit:0});async function s(e,t=[]){let[a]=await r.execute(e,t);return a}async function n(){try{await s(`
      CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);try{await s("ALTER TABLE contacts ADD COLUMN service VARCHAR(255) AFTER company;")}catch(e){}await s(`
      CREATE TABLE IF NOT EXISTS service_enquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await s(`
      CREATE TABLE IF NOT EXISTS queries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(50) NOT NULL,
        name VARCHAR(255),
        email VARCHAR(255),
        phone VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await s(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        rating INT NOT NULL,
        category VARCHAR(100) NOT NULL,
        comment TEXT NOT NULL,
        likes INT DEFAULT 0,
        status VARCHAR(50) DEFAULT 'approved',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let e=await s("SELECT COUNT(*) as count FROM reviews");if(0===e[0].count){for(let e of[{name:"Amitesh Sen",rating:5,category:"Verified Heir",comment:"Our family had 500 physical shares of Tata Motors from 1996. After my father passed, we had no idea how to demat them without a Will. KIRS drafted all succession bonds and guided us through court certification. Absolute experts!",likes:12},{name:"Dr. Rajesh Patel",rating:5,category:"Verified NRI Desk",comment:"I was living in New Jersey and trying to claim my deceased uncle's Reliance dividends from IEPF. The RTA rejected my documents twice due to spelling mismatches. The NRI desk at KIRS managed everything with embassy notarizations. Outstanding.",likes:9},{name:"Kavitha Sharma",rating:5,category:"Verified Owner",comment:"Highly professional work. My physical share certificate had signature differences from my bank account. They resolved the signature mismatch via Form ISR-2 updates and helped me convert everything to Demat in 2 months.",likes:8},{name:"Milind Deshpande",rating:5,category:"Verified Heir",comment:"We had a long-pending dispute regarding my late grandfather's bank deposits and physical mutual fund folios. KI&RS helped us clear the documentation roadblock under their success fee model. Extremely transparent and reliable team.",likes:15},{name:"Sunita Kulkarni",rating:5,category:"Verified Owner",comment:"Excellent guidance for unclaimed insurance policies. I had lost the original policy document of my husband. KIRS assisted in obtaining a duplicate policy and compiling the IEPF claim file. Highly recommended for Pune residents.",likes:6}])await s("INSERT INTO reviews (name, rating, category, comment, likes, status) VALUES (?, ?, ?, ?, ?, 'approved')",[e.name,e.rating,e.category,e.comment,e.likes]);console.log("Database initialized with seed review data.")}await s(`
      CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        short_desc TEXT,
        long_desc LONGTEXT,
        timeline VARCHAR(100),
        eligibility JSON,
        documents JSON,
        faqs JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let t=await s("SELECT COUNT(*) as count FROM services");if(0===t[0].count){for(let e of a.servicesData)await s(`INSERT INTO services (slug, title, short_desc, long_desc, timeline, eligibility, documents, faqs) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.shortDesc,e.longDesc,e.timeline,JSON.stringify(e.eligibility),JSON.stringify(e.documents),JSON.stringify(e.faqs)]);console.log("Database initialized with seed services data.")}await s(`
      CREATE TABLE IF NOT EXISTS blogs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        date VARCHAR(100),
        read_time VARCHAR(100),
        excerpt TEXT,
        content JSON,
        keywords JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let r=await s("SELECT COUNT(*) as count FROM blogs");if(0===r[0].count){for(let e of i.blogData)await s(`INSERT INTO blogs (slug, title, category, date, read_time, excerpt, content, keywords) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.category,e.date,e.readTime,e.excerpt,JSON.stringify(e.content),JSON.stringify(e.keywords)]);console.log("Database initialized with seed blog data.")}}catch(e){console.error("Database initialization failed:",e)}}e.s(["initializeDatabase",0,n,"query",0,s])},83616,e=>{"use strict";var t=e.i(16955),a=e.i(16208),i=e.i(18791),r=e.i(53535),s=e.i(95231),n=e.i(95054),o=e.i(87950),l=e.i(4341),c=e.i(62058),d=e.i(24346),u=e.i(76933),p=e.i(85277),R=e.i(44378),E=e.i(99537),T=e.i(62782),A=e.i(93695);e.i(59954);var m=e.i(83625),g=e.i(4279),N=e.i(38978),h=e.i(69692);function f(e){return{slug:e.slug,title:e.title,shortDesc:e.short_desc||"",longDesc:e.long_desc||"",timeline:e.timeline||"",eligibility:"string"==typeof e.eligibility?JSON.parse(e.eligibility):e.eligibility||[],documents:"string"==typeof e.documents?JSON.parse(e.documents):e.documents||[],faqs:"string"==typeof e.faqs?JSON.parse(e.faqs):e.faqs||[]}}async function y(){try{await (0,N.initializeDatabase)();let e=await (0,N.query)("SELECT * FROM services ORDER BY id ASC");if(e&&e.length>0){let t=e.map(f);return g.NextResponse.json(t)}return g.NextResponse.json(h.servicesData)}catch(e){return console.error("API Services GET Error:",e),g.NextResponse.json(h.servicesData)}}async function S(e){try{await (0,N.initializeDatabase)();let{slug:t,title:a,shortDesc:i,longDesc:r,timeline:s,eligibility:n,documents:o,faqs:l}=await e.json();if(!t||!a)return g.NextResponse.json({error:"Slug and title are required."},{status:400});return await (0,N.query)(`INSERT INTO services (slug, title, short_desc, long_desc, timeline, eligibility, documents, faqs)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE 
         title = VALUES(title),
         short_desc = VALUES(short_desc),
         long_desc = VALUES(long_desc),
         timeline = VALUES(timeline),
         eligibility = VALUES(eligibility),
         documents = VALUES(documents),
         faqs = VALUES(faqs)`,[t,a,i||"",r||"",s||"",JSON.stringify(n||[]),JSON.stringify(o||[]),JSON.stringify(l||[])]),g.NextResponse.json({success:!0,message:"Service saved to database successfully."})}catch(e){return console.error("API Services POST Error:",e),g.NextResponse.json({error:"Database operation failed: "+(e.message||e)},{status:500})}}e.s(["GET",0,y,"POST",0,S],35747);var C=e.i(35747);let v=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/services/route",pathname:"/api/services",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Data/AppData/App/ganesh/Personal/github/https-kirs.co.in/src/app/api/services/route.ts",nextConfigOutput:"",userland:C,...{}}),{workAsyncStorage:I,workUnitAsyncStorage:O,serverHooks:w}=v;async function x(e,t,i){i.requestMeta&&(0,r.setRequestMeta)(e,i.requestMeta),v.isDev&&(0,r.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let g="/api/services/route";g=g.replace(/\/index$/,"")||"/";let N=await v.prepare(e,t,{srcPage:g,multiZoneDraftMode:!1});if(!N)return t.statusCode=400,t.end("Bad Request"),null==i.waitUntil||i.waitUntil.call(i,Promise.resolve()),null;let{buildId:h,deploymentId:f,params:y,nextConfig:S,parsedUrl:C,isDraftMode:I,prerenderManifest:O,routerServerContext:w,isOnDemandRevalidate:x,revalidateOnlyGenerated:U,resolvedPathname:L,clientReferenceManifest:b,serverActionsManifest:D}=N,_=(0,o.normalizeAppPath)(g),M=!!(O.dynamicRoutes[_]||O.routes[L]),H=async()=>((null==w?void 0:w.render404)?await w.render404(e,t,C,!1):t.end("This page could not be found"),null);if(M&&!I){let e=!!O.routes[L],t=O.dynamicRoutes[_];if(t&&!1===t.fallback&&!e){if(S.adapterPath)return await H();throw new A.NoFallbackError}}let P=null;!M||v.isDev||I||(P="/index"===(P=L)?"/":P);let V=!0===v.isDev||!M,k=M&&!V;D&&b&&(0,n.setManifestsSingleton)({page:g,clientReferenceManifest:b,serverActionsManifest:D});let q=e.method||"GET",F=(0,s.getTracer)(),j=F.getActiveScopeSpan(),B=!!(null==w?void 0:w.isWrappedByNextServer),K=!!(0,r.getRequestMeta)(e,"minimalMode"),J=(0,r.getRequestMeta)(e,"incrementalCache")||await v.getIncrementalCache(e,S,O,K);null==J||J.resetRequestCache(),globalThis.__incrementalCache=J;let X={params:y,previewProps:O.preview,renderOpts:{experimental:{authInterrupts:!!S.experimental.authInterrupts},cacheComponents:!!S.cacheComponents,supportsDynamicResponse:V,incrementalCache:J,cacheLifeProfiles:S.cacheLife,waitUntil:i.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,i,r)=>v.onRequestError(e,t,i,r,w)},sharedContext:{buildId:h,deploymentId:f}},Y=new l.NodeNextRequest(e),G=new l.NodeNextResponse(t),z=c.NextRequestAdapter.fromNodeNextRequest(Y,(0,c.signalFromNodeResponse)(t));try{let r,n=async e=>v.handle(z,X).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=F.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=a.get("next.route");if(i){let t=`${q} ${i}`;e.setAttributes({"next.route":i,"http.route":i,"next.span_name":t}),e.updateName(t),r&&r!==e&&(r.setAttribute("http.route",i),r.updateName(t))}else e.updateName(`${q} ${g}`)}),o=async r=>{var s,o;let l=async({previousCacheEntry:a})=>{try{if(!K&&x&&U&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await n(r);e.fetchMetrics=X.renderOpts.fetchMetrics;let o=X.renderOpts.pendingWaitUntil;o&&i.waitUntil&&(i.waitUntil(o),o=void 0);let l=X.renderOpts.collectedTags;if(!M)return await (0,p.sendResponse)(Y,G,s,X.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,R.toNodeOutgoingHttpHeaders)(s.headers);l&&(t[T.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==X.renderOpts.collectedRevalidate&&!(X.renderOpts.collectedRevalidate>=T.INFINITE_CACHE)&&X.renderOpts.collectedRevalidate,i=void 0===X.renderOpts.collectedExpire||X.renderOpts.collectedExpire>=T.INFINITE_CACHE?void 0:X.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:i}}}}catch(t){throw(null==a?void 0:a.isStale)&&await v.onRequestError(e,t,{routerKind:"App Router",routePath:g,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:x})},!1,w),t}},c=await v.handleResponse({req:e,nextConfig:S,cacheKey:P,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:O,isRoutePPREnabled:!1,isOnDemandRevalidate:x,revalidateOnlyGenerated:U,responseGenerator:l,waitUntil:i.waitUntil,isMinimalMode:K});if(!M)return null;if((null==c||null==(s=c.value)?void 0:s.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==c||null==(o=c.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",x?"REVALIDATED":c.isMiss?"MISS":c.isStale?"STALE":"HIT"),I&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let d=(0,R.fromNodeOutgoingHttpHeaders)(c.value.headers);return K&&M||d.delete(T.NEXT_CACHE_TAGS_HEADER),!c.cacheControl||t.getHeader("Cache-Control")||d.get("Cache-Control")||d.set("Cache-Control",(0,E.getCacheControlHeader)(c.cacheControl)),await (0,p.sendResponse)(Y,G,new Response(c.value.body,{headers:d,status:c.value.status||200})),null};B&&j?await o(j):(r=F.getActiveScopeSpan(),await F.withPropagatedContext(e.headers,()=>F.trace(d.BaseServerSpan.handleRequest,{spanName:`${q} ${g}`,kind:s.SpanKind.SERVER,attributes:{"http.method":q,"http.target":e.url}},o),void 0,!B))}catch(t){if(t instanceof A.NoFallbackError||await v.onRequestError(e,t,{routerKind:"App Router",routePath:_,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:x})},!1,w),M)throw t;return await (0,p.sendResponse)(Y,G,new Response(null,{status:500})),null}}e.s(["handler",0,x,"patchFetch",0,function(){return(0,i.patchFetch)({workAsyncStorage:I,workUnitAsyncStorage:O})},"routeModule",0,v,"serverHooks",0,w,"workAsyncStorage",0,I,"workUnitAsyncStorage",0,O],83616)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1fx8xeh._.js.map