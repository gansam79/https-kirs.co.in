1:"$Sreact.fragment"
2:I[33032,["/stagging/_next/static/chunks/0m200stc-oegr.js","/stagging/_next/static/chunks/1ejk9jqq5vbjp.js"],"default"]
3:I[38981,["/stagging/_next/static/chunks/0m200stc-oegr.js","/stagging/_next/static/chunks/1ejk9jqq5vbjp.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"DCjz9ELxi-SDwgju_bW1h"}
