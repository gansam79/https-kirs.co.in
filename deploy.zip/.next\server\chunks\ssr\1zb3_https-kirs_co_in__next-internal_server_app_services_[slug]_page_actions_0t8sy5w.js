module.exports=[49229,(a,b,c)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_services_%5Bslug%5D_page_actions_0t8sy5w.js.map