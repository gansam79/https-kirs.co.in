1:"$Sreact.fragment"
2:I[33032,["/_next/static/chunks/0frmf2_5roz-9.js","/_next/static/chunks/3x_vse9i6mchh.js","/_next/static/chunks/1ejk9jqq5vbjp.js"],"default"]
3:I[38981,["/_next/static/chunks/0frmf2_5roz-9.js","/_next/static/chunks/3x_vse9i6mchh.js","/_next/static/chunks/1ejk9jqq5vbjp.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"xEyfr4GY2GJqbl8ie4Kir"}
