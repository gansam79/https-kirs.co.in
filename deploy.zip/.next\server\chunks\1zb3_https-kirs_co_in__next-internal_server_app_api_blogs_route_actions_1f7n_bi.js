module.exports=[10321,(e,o,d)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_api_blogs_route_actions_1f7n_bi.js.map