module.exports=[8743,(e,o,d)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_sitemap_xml_route_actions_1845e5b.js.map