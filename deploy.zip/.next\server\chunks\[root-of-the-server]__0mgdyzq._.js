module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},14747,(e,t,a)=>{t.exports=e.x("path",()=>require("path"))},38978,e=>{"use strict";var t=e.i(5075),a=e.i(69692),i=e.i(25147);let r=t.default.createPool({host:process.env.DB_HOST||"193.203.184.226",user:process.env.DB_USER||"u686584126_kirsdb",password:process.env.DB_PASSWORD||"Kirs@2026Db",database:process.env.DB_NAME||"u686584126_kirsdb",waitForConnections:!0,connectionLimit:10,queueLimit:0});async function s(e,t=[]){let[a]=await r.execute(e,t);return a}async function n(){try{await s(`
      CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);try{await s("ALTER TABLE contacts ADD COLUMN service VARCHAR(255) AFTER company;")}catch(e){}await s(`
      CREATE TABLE IF NOT EXISTS service_enquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await s(`
      CREATE TABLE IF NOT EXISTS queries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(50) NOT NULL,
        name VARCHAR(255),
        email VARCHAR(255),
        phone VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await s(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        rating INT NOT NULL,
        category VARCHAR(100) NOT NULL,
        comment TEXT NOT NULL,
        likes INT DEFAULT 0,
        status VARCHAR(50) DEFAULT 'approved',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let e=await s("SELECT COUNT(*) as count FROM reviews");if(0===e[0].count){for(let e of[{name:"Amitesh Sen",rating:5,category:"Verified Heir",comment:"Our family had 500 physical shares of Tata Motors from 1996. After my father passed, we had no idea how to demat them without a Will. KIRS drafted all succession bonds and guided us through court certification. Absolute experts!",likes:12},{name:"Dr. Rajesh Patel",rating:5,category:"Verified NRI Desk",comment:"I was living in New Jersey and trying to claim my deceased uncle's Reliance dividends from IEPF. The RTA rejected my documents twice due to spelling mismatches. The NRI desk at KIRS managed everything with embassy notarizations. Outstanding.",likes:9},{name:"Kavitha Sharma",rating:5,category:"Verified Owner",comment:"Highly professional work. My physical share certificate had signature differences from my bank account. They resolved the signature mismatch via Form ISR-2 updates and helped me convert everything to Demat in 2 months.",likes:8},{name:"Milind Deshpande",rating:5,category:"Verified Heir",comment:"We had a long-pending dispute regarding my late grandfather's bank deposits and physical mutual fund folios. KI&RS helped us clear the documentation roadblock under their success fee model. Extremely transparent and reliable team.",likes:15},{name:"Sunita Kulkarni",rating:5,category:"Verified Owner",comment:"Excellent guidance for unclaimed insurance policies. I had lost the original policy document of my husband. KIRS assisted in obtaining a duplicate policy and compiling the IEPF claim file. Highly recommended for Pune residents.",likes:6}])await s("INSERT INTO reviews (name, rating, category, comment, likes, status) VALUES (?, ?, ?, ?, ?, 'approved')",[e.name,e.rating,e.category,e.comment,e.likes]);console.log("Database initialized with seed review data.")}await s(`
      CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        short_desc TEXT,
        long_desc LONGTEXT,
        timeline VARCHAR(100),
        eligibility JSON,
        documents JSON,
        faqs JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let t=await s("SELECT COUNT(*) as count FROM services");if(0===t[0].count){for(let e of a.servicesData)await s(`INSERT INTO services (slug, title, short_desc, long_desc, timeline, eligibility, documents, faqs) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.shortDesc,e.longDesc,e.timeline,JSON.stringify(e.eligibility),JSON.stringify(e.documents),JSON.stringify(e.faqs)]);console.log("Database initialized with seed services data.")}await s(`
      CREATE TABLE IF NOT EXISTS blogs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        date VARCHAR(100),
        read_time VARCHAR(100),
        excerpt TEXT,
        content JSON,
        keywords JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let r=await s("SELECT COUNT(*) as count FROM blogs");if(0===r[0].count){for(let e of i.blogData)await s(`INSERT INTO blogs (slug, title, category, date, read_time, excerpt, content, keywords) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.category,e.date,e.readTime,e.excerpt,JSON.stringify(e.content),JSON.stringify(e.keywords)]);console.log("Database initialized with seed blog data.")}}catch(e){console.error("Database initialization failed:",e)}}e.s(["initializeDatabase",0,n,"query",0,s])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0mgdyzq._.js.map