var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/services/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__1148yzy._.js")
R.c("server/chunks/07em_App_ganesh_Personal_github_https-kirs_co_in_src_data_servicesData_ts_0byghjg._.js")
R.c("server/chunks/[root-of-the-server]__1ss5kys._.js")
R.c("server/chunks/[root-of-the-server]__0v77pak._.js")
R.c("server/chunks/0tuu_co_in__next-internal_server_app_api_services_[slug]_route_actions_1g8_99k.js")
R.m(10255)
module.exports=R.m(10255).exports
