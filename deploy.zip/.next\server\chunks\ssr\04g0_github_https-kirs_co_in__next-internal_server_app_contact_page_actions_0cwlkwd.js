module.exports=[7062,(a,b,c)=>{}];

//# sourceMappingURL=04g0_github_https-kirs_co_in__next-internal_server_app_contact_page_actions_0cwlkwd.js.map