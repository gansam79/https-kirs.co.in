module.exports=[40431,(e,o,d)=>{}];

//# sourceMappingURL=0tuu_co_in__next-internal_server_app_api_services_%5Bslug%5D_route_actions_1g8_99k.js.map