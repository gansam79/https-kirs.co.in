module.exports=[5962,(a,b,c)=>{}];

//# sourceMappingURL=1kbh_Personal_github_https-kirs_co_in__next-internal_server_app_page_actions_1quy_m9.js.map