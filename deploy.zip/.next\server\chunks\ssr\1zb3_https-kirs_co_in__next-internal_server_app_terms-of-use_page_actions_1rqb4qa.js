module.exports=[19336,(a,b,c)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_terms-of-use_page_actions_1rqb4qa.js.map