module.exports=[16499,(a,b,c)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_market-watch_page_actions_0getucr.js.map