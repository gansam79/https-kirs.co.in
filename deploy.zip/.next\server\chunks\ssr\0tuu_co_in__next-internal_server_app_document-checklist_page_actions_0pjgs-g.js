module.exports=[6150,(a,b,c)=>{}];

//# sourceMappingURL=0tuu_co_in__next-internal_server_app_document-checklist_page_actions_0pjgs-g.js.map