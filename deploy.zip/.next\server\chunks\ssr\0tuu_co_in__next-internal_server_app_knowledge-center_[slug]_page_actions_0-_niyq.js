module.exports=[78086,(a,b,c)=>{}];

//# sourceMappingURL=0tuu_co_in__next-internal_server_app_knowledge-center_%5Bslug%5D_page_actions_0-_niyq.js.map