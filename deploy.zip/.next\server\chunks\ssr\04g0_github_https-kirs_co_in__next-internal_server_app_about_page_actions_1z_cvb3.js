module.exports=[94286,(a,b,c)=>{}];

//# sourceMappingURL=04g0_github_https-kirs_co_in__next-internal_server_app_about_page_actions_1z_cvb3.js.map