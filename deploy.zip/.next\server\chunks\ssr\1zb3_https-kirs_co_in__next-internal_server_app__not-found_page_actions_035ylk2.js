module.exports=[16505,(a,b,c)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app__not-found_page_actions_035ylk2.js.map