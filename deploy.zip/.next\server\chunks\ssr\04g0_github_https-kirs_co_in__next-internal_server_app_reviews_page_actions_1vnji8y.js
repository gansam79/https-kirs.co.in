module.exports=[66988,(a,b,c)=>{}];

//# sourceMappingURL=04g0_github_https-kirs_co_in__next-internal_server_app_reviews_page_actions_1vnji8y.js.map