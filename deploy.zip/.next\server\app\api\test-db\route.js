var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-db/route.js")
R.c("server/chunks/[root-of-the-server]__1p6p2ae._.js")
R.c("server/chunks/[root-of-the-server]__0v77pak._.js")
R.c("server/chunks/[root-of-the-server]__1ss5kys._.js")
R.c("server/chunks/1zb3_https-kirs_co_in__next-internal_server_app_api_test-db_route_actions_14oasg7.js")
R.m(7052)
module.exports=R.m(7052).exports
