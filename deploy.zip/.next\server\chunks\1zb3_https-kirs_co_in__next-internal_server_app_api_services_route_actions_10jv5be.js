module.exports=[92938,(e,o,d)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_api_services_route_actions_10jv5be.js.map