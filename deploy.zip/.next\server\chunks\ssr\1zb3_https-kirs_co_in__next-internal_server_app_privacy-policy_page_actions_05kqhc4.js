module.exports=[40508,(a,b,c)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_privacy-policy_page_actions_05kqhc4.js.map