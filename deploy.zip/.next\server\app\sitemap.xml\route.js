var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0iu-w6-._.js")
R.c("server/chunks/[root-of-the-server]__1ss5kys._.js")
R.c("server/chunks/1y1n_next_dist_esm_build_templates_app-route_1vs929j.js")
R.c("server/chunks/1zb3_https-kirs_co_in__next-internal_server_app_sitemap_xml_route_actions_1845e5b.js")
R.m(55101)
module.exports=R.m(55101).exports
