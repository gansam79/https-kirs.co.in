var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__13iwe0z._.js")
R.c("server/chunks/[root-of-the-server]__1ss5kys._.js")
R.c("server/chunks/07em_App_ganesh_Personal_github_https-kirs_co_in_src_data_servicesData_ts_0byghjg._.js")
R.c("server/chunks/1zb3_https-kirs_co_in__next-internal_server_app_sitemap_xml_route_actions_1845e5b.js")
R.m(55101)
module.exports=R.m(55101).exports
