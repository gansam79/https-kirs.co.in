module.exports=[6386,(e,o,d)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_api_reviews_route_actions_15vo_5c.js.map