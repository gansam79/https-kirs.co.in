module.exports=[7076,(e,o,d)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_robots_txt_route_actions_1-pksyw.js.map