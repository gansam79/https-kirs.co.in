module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},38978,e=>{"use strict";var t=e.i(5075),a=e.i(69692),r=e.i(25147);let i=t.default.createPool({host:process.env.DB_HOST||"193.203.184.226",user:process.env.DB_USER||"u686584126_kirsdb",password:process.env.DB_PASSWORD||"Kirs@2026Db",database:process.env.DB_NAME||"u686584126_kirsdb",waitForConnections:!0,connectionLimit:10,queueLimit:0});async function s(e,t=[]){let[a]=await i.execute(e,t);return a}async function n(){try{await s(`
      CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);try{await s("ALTER TABLE contacts ADD COLUMN service VARCHAR(255) AFTER company;")}catch(e){}await s(`
      CREATE TABLE IF NOT EXISTS service_enquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await s(`
      CREATE TABLE IF NOT EXISTS queries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(50) NOT NULL,
        name VARCHAR(255),
        email VARCHAR(255),
        phone VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await s(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        rating INT NOT NULL,
        category VARCHAR(100) NOT NULL,
        comment TEXT NOT NULL,
        likes INT DEFAULT 0,
        status VARCHAR(50) DEFAULT 'approved',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let e=await s("SELECT COUNT(*) as count FROM reviews");if(0===e[0].count){for(let e of[{name:"Amitesh Sen",rating:5,category:"Verified Heir",comment:"Our family had 500 physical shares of Tata Motors from 1996. After my father passed, we had no idea how to demat them without a Will. KIRS drafted all succession bonds and guided us through court certification. Absolute experts!",likes:12},{name:"Dr. Rajesh Patel",rating:5,category:"Verified NRI Desk",comment:"I was living in New Jersey and trying to claim my deceased uncle's Reliance dividends from IEPF. The RTA rejected my documents twice due to spelling mismatches. The NRI desk at KIRS managed everything with embassy notarizations. Outstanding.",likes:9},{name:"Kavitha Sharma",rating:5,category:"Verified Owner",comment:"Highly professional work. My physical share certificate had signature differences from my bank account. They resolved the signature mismatch via Form ISR-2 updates and helped me convert everything to Demat in 2 months.",likes:8},{name:"Milind Deshpande",rating:5,category:"Verified Heir",comment:"We had a long-pending dispute regarding my late grandfather's bank deposits and physical mutual fund folios. KI&RS helped us clear the documentation roadblock under their success fee model. Extremely transparent and reliable team.",likes:15},{name:"Sunita Kulkarni",rating:5,category:"Verified Owner",comment:"Excellent guidance for unclaimed insurance policies. I had lost the original policy document of my husband. KIRS assisted in obtaining a duplicate policy and compiling the IEPF claim file. Highly recommended for Pune residents.",likes:6}])await s("INSERT INTO reviews (name, rating, category, comment, likes, status) VALUES (?, ?, ?, ?, ?, 'approved')",[e.name,e.rating,e.category,e.comment,e.likes]);console.log("Database initialized with seed review data.")}await s(`
      CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        short_desc TEXT,
        long_desc LONGTEXT,
        timeline VARCHAR(100),
        eligibility JSON,
        documents JSON,
        faqs JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let t=await s("SELECT COUNT(*) as count FROM services");if(0===t[0].count){for(let e of a.servicesData)await s(`INSERT INTO services (slug, title, short_desc, long_desc, timeline, eligibility, documents, faqs) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.shortDesc,e.longDesc,e.timeline,JSON.stringify(e.eligibility),JSON.stringify(e.documents),JSON.stringify(e.faqs)]);console.log("Database initialized with seed services data.")}await s(`
      CREATE TABLE IF NOT EXISTS blogs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        date VARCHAR(100),
        read_time VARCHAR(100),
        excerpt TEXT,
        content JSON,
        keywords JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let i=await s("SELECT COUNT(*) as count FROM blogs");if(0===i[0].count){for(let e of r.blogData)await s(`INSERT INTO blogs (slug, title, category, date, read_time, excerpt, content, keywords) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.category,e.date,e.readTime,e.excerpt,JSON.stringify(e.content),JSON.stringify(e.keywords)]);console.log("Database initialized with seed blog data.")}}catch(e){console.error("Database initialization failed:",e)}}e.s(["initializeDatabase",0,n,"query",0,s])},24907,e=>{"use strict";var t=e.i(16955),a=e.i(16208),r=e.i(18791),i=e.i(53535),s=e.i(95231),n=e.i(95054),o=e.i(87950),l=e.i(4341),d=e.i(62058),c=e.i(24346),u=e.i(76933),R=e.i(85277),p=e.i(44378),T=e.i(99537),E=e.i(62782),A=e.i(93695);e.i(59954);var m=e.i(83625),N=e.i(4279),h=e.i(38978);async function g(){try{await (0,h.initializeDatabase)();let e=await (0,h.query)("SELECT * FROM reviews WHERE status = 'approved' ORDER BY id DESC");return N.NextResponse.json(e)}catch(e){return console.error("API Reviews GET Error:",e),N.NextResponse.json({error:"Database operation failed: "+(e.message||e)},{status:500})}}async function f(e){try{await (0,h.initializeDatabase)();let{name:t,rating:a,category:r,comment:i}=await e.json();if(!t||!a||!r||!i)return N.NextResponse.json({error:"Missing required fields (name, rating, category, comment)."},{status:400});return await (0,h.query)("INSERT INTO reviews (name, rating, category, comment, likes, status) VALUES (?, ?, ?, ?, 0, 'approved')",[t,Number(a),r,i]),N.NextResponse.json({success:!0,message:"Review posted successfully."})}catch(e){return console.error("API Reviews POST Error:",e),N.NextResponse.json({error:"Database operation failed: "+(e.message||e)},{status:500})}}async function C(e){try{await (0,h.initializeDatabase)();let{searchParams:t}=new URL(e.url),a=t.get("id");if(!a)return N.NextResponse.json({error:"Review ID is required."},{status:400});return await (0,h.query)("UPDATE reviews SET likes = likes + 1 WHERE id = ?",[a]),N.NextResponse.json({success:!0,message:"Review liked successfully."})}catch(e){return console.error("API Reviews PATCH Error:",e),N.NextResponse.json({error:"Database operation failed: "+(e.message||e)},{status:500})}}e.s(["GET",0,g,"PATCH",0,C,"POST",0,f],94431);var v=e.i(94431);let y=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/reviews/route",pathname:"/api/reviews",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Data/AppData/App/ganesh/Personal/github/https-kirs.co.in/src/app/api/reviews/route.ts",nextConfigOutput:"",userland:v,...{}}),{workAsyncStorage:w,workUnitAsyncStorage:I,serverHooks:S}=y;async function x(e,t,r){r.requestMeta&&(0,i.setRequestMeta)(e,r.requestMeta),y.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let N="/api/reviews/route";N=N.replace(/\/index$/,"")||"/";let h=await y.prepare(e,t,{srcPage:N,multiZoneDraftMode:!1});if(!h)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:g,deploymentId:f,params:C,nextConfig:v,parsedUrl:w,isDraftMode:I,prerenderManifest:S,routerServerContext:x,isOnDemandRevalidate:O,revalidateOnlyGenerated:U,resolvedPathname:L,clientReferenceManifest:b,serverActionsManifest:D}=h,H=(0,o.normalizeAppPath)(N),M=!!(S.dynamicRoutes[H]||S.routes[L]),P=async()=>((null==x?void 0:x.render404)?await x.render404(e,t,w,!1):t.end("This page could not be found"),null);if(M&&!I){let e=!!S.routes[L],t=S.dynamicRoutes[H];if(t&&!1===t.fallback&&!e){if(v.adapterPath)return await P();throw new A.NoFallbackError}}let _=null;!M||y.isDev||I||(_="/index"===(_=L)?"/":_);let k=!0===y.isDev||!M,V=M&&!k;D&&b&&(0,n.setManifestsSingleton)({page:N,clientReferenceManifest:b,serverActionsManifest:D});let q=e.method||"GET",F=(0,s.getTracer)(),j=F.getActiveScopeSpan(),B=!!(null==x?void 0:x.isWrappedByNextServer),K=!!(0,i.getRequestMeta)(e,"minimalMode"),X=(0,i.getRequestMeta)(e,"incrementalCache")||await y.getIncrementalCache(e,v,S,K);null==X||X.resetRequestCache(),globalThis.__incrementalCache=X;let Y={params:C,previewProps:S.preview,renderOpts:{experimental:{authInterrupts:!!v.experimental.authInterrupts},cacheComponents:!!v.cacheComponents,supportsDynamicResponse:k,incrementalCache:X,cacheLifeProfiles:v.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,i)=>y.onRequestError(e,t,r,i,x)},sharedContext:{buildId:g,deploymentId:f}},G=new l.NodeNextRequest(e),J=new l.NodeNextResponse(t),z=d.NextRequestAdapter.fromNodeNextRequest(G,(0,d.signalFromNodeResponse)(t));try{let i,n=async e=>y.handle(z,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=F.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${q} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),i&&i!==e&&(i.setAttribute("http.route",r),i.updateName(t))}else e.updateName(`${q} ${N}`)}),o=async i=>{var s,o;let l=async({previousCacheEntry:a})=>{try{if(!K&&O&&U&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await n(i);e.fetchMetrics=Y.renderOpts.fetchMetrics;let o=Y.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let l=Y.renderOpts.collectedTags;if(!M)return await (0,R.sendResponse)(G,J,s,Y.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(s.headers);l&&(t[E.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=E.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,r=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=E.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await y.onRequestError(e,t,{routerKind:"App Router",routePath:N,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:V,isOnDemandRevalidate:O})},!1,x),t}},d=await y.handleResponse({req:e,nextConfig:v,cacheKey:_,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:O,revalidateOnlyGenerated:U,responseGenerator:l,waitUntil:r.waitUntil,isMinimalMode:K});if(!M)return null;if((null==d||null==(s=d.value)?void 0:s.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(o=d.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",O?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),I&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,p.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&M||c.delete(E.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,T.getCacheControlHeader)(d.cacheControl)),await (0,R.sendResponse)(G,J,new Response(d.value.body,{headers:c,status:d.value.status||200})),null};B&&j?await o(j):(i=F.getActiveScopeSpan(),await F.withPropagatedContext(e.headers,()=>F.trace(c.BaseServerSpan.handleRequest,{spanName:`${q} ${N}`,kind:s.SpanKind.SERVER,attributes:{"http.method":q,"http.target":e.url}},o),void 0,!B))}catch(t){if(t instanceof A.NoFallbackError||await y.onRequestError(e,t,{routerKind:"App Router",routePath:H,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:V,isOnDemandRevalidate:O})},!1,x),M)throw t;return await (0,R.sendResponse)(G,J,new Response(null,{status:500})),null}}e.s(["handler",0,x,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:w,workUnitAsyncStorage:I})},"routeModule",0,y,"serverHooks",0,S,"workAsyncStorage",0,w,"workUnitAsyncStorage",0,I],24907)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0l2dqux._.js.map