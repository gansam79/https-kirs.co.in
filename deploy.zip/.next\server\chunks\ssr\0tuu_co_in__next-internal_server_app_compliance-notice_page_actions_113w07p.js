module.exports=[6485,(a,b,c)=>{}];

//# sourceMappingURL=0tuu_co_in__next-internal_server_app_compliance-notice_page_actions_113w07p.js.map