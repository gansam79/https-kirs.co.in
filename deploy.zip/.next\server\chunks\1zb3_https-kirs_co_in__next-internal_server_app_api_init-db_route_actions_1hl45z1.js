module.exports=[70958,(e,o,d)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app_api_init-db_route_actions_1hl45z1.js.map