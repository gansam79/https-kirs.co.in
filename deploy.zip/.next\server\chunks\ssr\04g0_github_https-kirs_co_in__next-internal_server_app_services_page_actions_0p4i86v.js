module.exports=[26033,(a,b,c)=>{}];

//# sourceMappingURL=04g0_github_https-kirs_co_in__next-internal_server_app_services_page_actions_0p4i86v.js.map