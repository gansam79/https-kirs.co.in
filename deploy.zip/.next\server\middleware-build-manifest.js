globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/DCjz9ELxi-SDwgju_bW1h/_buildManifest.js",
    "static/DCjz9ELxi-SDwgju_bW1h/_ssgManifest.js",
    "static/DCjz9ELxi-SDwgju_bW1h/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/24rn3ysvb0iz8.js",
    "static/chunks/0omvsu1go7b-y.js",
    "static/chunks/3_noks8von3fs.js",
    "static/chunks/12swdt9u5kkrb.js",
    "static/chunks/turbopack-283fuwpf2ss7i.js"
  ]
};
