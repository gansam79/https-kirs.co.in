globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/xEyfr4GY2GJqbl8ie4Kir/_buildManifest.js",
    "static/xEyfr4GY2GJqbl8ie4Kir/_ssgManifest.js",
    "static/xEyfr4GY2GJqbl8ie4Kir/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/24rn3ysvb0iz8.js",
    "static/chunks/0omvsu1go7b-y.js",
    "static/chunks/3hfkjic1jkwi7.js",
    "static/chunks/12swdt9u5kkrb.js",
    "static/chunks/turbopack-1upgrf3o6nus0.js"
  ]
};
