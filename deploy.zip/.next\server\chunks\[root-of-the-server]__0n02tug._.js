module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},38978,e=>{"use strict";var t=e.i(5075),a=e.i(69692),r=e.i(25147);let n=t.default.createPool({host:process.env.DB_HOST||"193.203.184.226",user:process.env.DB_USER||"u686584126_kirsdb",password:process.env.DB_PASSWORD||"Kirs@2026Db",database:process.env.DB_NAME||"u686584126_kirsdb",waitForConnections:!0,connectionLimit:10,queueLimit:0});async function i(e,t=[]){let[a]=await n.execute(e,t);return a}async function s(){try{await i(`
      CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);try{await i("ALTER TABLE contacts ADD COLUMN service VARCHAR(255) AFTER company;")}catch(e){}await i(`
      CREATE TABLE IF NOT EXISTS service_enquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await i(`
      CREATE TABLE IF NOT EXISTS queries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(50) NOT NULL,
        name VARCHAR(255),
        email VARCHAR(255),
        phone VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await i(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        rating INT NOT NULL,
        category VARCHAR(100) NOT NULL,
        comment TEXT NOT NULL,
        likes INT DEFAULT 0,
        status VARCHAR(50) DEFAULT 'approved',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let e=await i("SELECT COUNT(*) as count FROM reviews");if(0===e[0].count){for(let e of[{name:"Amitesh Sen",rating:5,category:"Verified Heir",comment:"Our family had 500 physical shares of Tata Motors from 1996. After my father passed, we had no idea how to demat them without a Will. KIRS drafted all succession bonds and guided us through court certification. Absolute experts!",likes:12},{name:"Dr. Rajesh Patel",rating:5,category:"Verified NRI Desk",comment:"I was living in New Jersey and trying to claim my deceased uncle's Reliance dividends from IEPF. The RTA rejected my documents twice due to spelling mismatches. The NRI desk at KIRS managed everything with embassy notarizations. Outstanding.",likes:9},{name:"Kavitha Sharma",rating:5,category:"Verified Owner",comment:"Highly professional work. My physical share certificate had signature differences from my bank account. They resolved the signature mismatch via Form ISR-2 updates and helped me convert everything to Demat in 2 months.",likes:8},{name:"Milind Deshpande",rating:5,category:"Verified Heir",comment:"We had a long-pending dispute regarding my late grandfather's bank deposits and physical mutual fund folios. KI&RS helped us clear the documentation roadblock under their success fee model. Extremely transparent and reliable team.",likes:15},{name:"Sunita Kulkarni",rating:5,category:"Verified Owner",comment:"Excellent guidance for unclaimed insurance policies. I had lost the original policy document of my husband. KIRS assisted in obtaining a duplicate policy and compiling the IEPF claim file. Highly recommended for Pune residents.",likes:6}])await i("INSERT INTO reviews (name, rating, category, comment, likes, status) VALUES (?, ?, ?, ?, ?, 'approved')",[e.name,e.rating,e.category,e.comment,e.likes]);console.log("Database initialized with seed review data.")}await i(`
      CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        short_desc TEXT,
        long_desc LONGTEXT,
        timeline VARCHAR(100),
        eligibility JSON,
        documents JSON,
        faqs JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let t=await i("SELECT COUNT(*) as count FROM services");if(0===t[0].count){for(let e of a.servicesData)await i(`INSERT INTO services (slug, title, short_desc, long_desc, timeline, eligibility, documents, faqs) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.shortDesc,e.longDesc,e.timeline,JSON.stringify(e.eligibility),JSON.stringify(e.documents),JSON.stringify(e.faqs)]);console.log("Database initialized with seed services data.")}await i(`
      CREATE TABLE IF NOT EXISTS blogs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        date VARCHAR(100),
        read_time VARCHAR(100),
        excerpt TEXT,
        content JSON,
        keywords JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let n=await i("SELECT COUNT(*) as count FROM blogs");if(0===n[0].count){for(let e of r.blogData)await i(`INSERT INTO blogs (slug, title, category, date, read_time, excerpt, content, keywords) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.category,e.date,e.readTime,e.excerpt,JSON.stringify(e.content),JSON.stringify(e.keywords)]);console.log("Database initialized with seed blog data.")}}catch(e){console.error("Database initialization failed:",e)}}e.s(["initializeDatabase",0,s,"query",0,i])},15523,e=>{"use strict";var t=e.i(16955),a=e.i(16208),r=e.i(18791),n=e.i(53535),i=e.i(95231),s=e.i(95054),o=e.i(87950),l=e.i(4341),d=e.i(62058),c=e.i(24346),u=e.i(76933),p=e.i(85277),R=e.i(44378),T=e.i(99537),E=e.i(62782),A=e.i(93695);e.i(59954);var g=e.i(83625),N=e.i(4279),m=e.i(38978),h=e.i(25147);function f(e){return{slug:e.slug,title:e.title,category:e.category||"",date:e.date||"",readTime:e.read_time||"",excerpt:e.excerpt||"",content:"string"==typeof e.content?JSON.parse(e.content):e.content||[],keywords:"string"==typeof e.keywords?JSON.parse(e.keywords):e.keywords||[]}}async function C(e){try{let{searchParams:t}=new URL(e.url),a=t.get("slug");if(await (0,m.initializeDatabase)(),a){let e=await (0,m.query)("SELECT * FROM blogs WHERE slug = ? LIMIT 1",[a]);if(e&&e.length>0)return N.NextResponse.json(f(e[0]));let t=h.blogData.find(e=>e.slug===a);if(t)return N.NextResponse.json(t);return N.NextResponse.json({error:"Article not found"},{status:404})}let r=await (0,m.query)("SELECT * FROM blogs ORDER BY id DESC");if(r&&r.length>0)return N.NextResponse.json(r.map(f));return N.NextResponse.json(h.blogData)}catch(e){return console.error("API Blogs GET Error:",e),N.NextResponse.json(h.blogData)}}e.s(["GET",0,C],38323);var y=e.i(38323);let I=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/blogs/route",pathname:"/api/blogs",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Data/AppData/App/ganesh/Personal/github/https-kirs.co.in/src/app/api/blogs/route.ts",nextConfigOutput:"",userland:y,...{}}),{workAsyncStorage:S,workUnitAsyncStorage:v,serverHooks:w}=I;async function x(e,t,r){r.requestMeta&&(0,n.setRequestMeta)(e,r.requestMeta),I.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let N="/api/blogs/route";N=N.replace(/\/index$/,"")||"/";let m=await I.prepare(e,t,{srcPage:N,multiZoneDraftMode:!1});if(!m)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:h,deploymentId:f,params:C,nextConfig:y,parsedUrl:S,isDraftMode:v,prerenderManifest:w,routerServerContext:x,isOnDemandRevalidate:O,revalidateOnlyGenerated:b,resolvedPathname:L,clientReferenceManifest:U,serverActionsManifest:D}=m,M=(0,o.normalizeAppPath)(N),H=!!(w.dynamicRoutes[M]||w.routes[L]),_=async()=>((null==x?void 0:x.render404)?await x.render404(e,t,S,!1):t.end("This page could not be found"),null);if(H&&!v){let e=!!w.routes[L],t=w.dynamicRoutes[M];if(t&&!1===t.fallback&&!e){if(y.adapterPath)return await _();throw new A.NoFallbackError}}let P=null;!H||I.isDev||v||(P="/index"===(P=L)?"/":P);let k=!0===I.isDev||!H,V=H&&!k;D&&U&&(0,s.setManifestsSingleton)({page:N,clientReferenceManifest:U,serverActionsManifest:D});let F=e.method||"GET",q=(0,i.getTracer)(),j=q.getActiveScopeSpan(),B=!!(null==x?void 0:x.isWrappedByNextServer),K=!!(0,n.getRequestMeta)(e,"minimalMode"),X=(0,n.getRequestMeta)(e,"incrementalCache")||await I.getIncrementalCache(e,y,w,K);null==X||X.resetRequestCache(),globalThis.__incrementalCache=X;let J={params:C,previewProps:w.preview,renderOpts:{experimental:{authInterrupts:!!y.experimental.authInterrupts},cacheComponents:!!y.cacheComponents,supportsDynamicResponse:k,incrementalCache:X,cacheLifeProfiles:y.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,n)=>I.onRequestError(e,t,r,n,x)},sharedContext:{buildId:h,deploymentId:f}},Y=new l.NodeNextRequest(e),G=new l.NodeNextResponse(t),$=d.NextRequestAdapter.fromNodeNextRequest(Y,(0,d.signalFromNodeResponse)(t));try{let n,s=async e=>I.handle($,J).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=q.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${F} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",r),n.updateName(t))}else e.updateName(`${F} ${N}`)}),o=async n=>{var i,o;let l=async({previousCacheEntry:a})=>{try{if(!K&&O&&b&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let i=await s(n);e.fetchMetrics=J.renderOpts.fetchMetrics;let o=J.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let l=J.renderOpts.collectedTags;if(!H)return await (0,p.sendResponse)(Y,G,i,J.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),t=(0,R.toNodeOutgoingHttpHeaders)(i.headers);l&&(t[E.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==J.renderOpts.collectedRevalidate&&!(J.renderOpts.collectedRevalidate>=E.INFINITE_CACHE)&&J.renderOpts.collectedRevalidate,r=void 0===J.renderOpts.collectedExpire||J.renderOpts.collectedExpire>=E.INFINITE_CACHE?void 0:J.renderOpts.collectedExpire;return{value:{kind:g.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await I.onRequestError(e,t,{routerKind:"App Router",routePath:N,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:V,isOnDemandRevalidate:O})},!1,x),t}},d=await I.handleResponse({req:e,nextConfig:y,cacheKey:P,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:w,isRoutePPREnabled:!1,isOnDemandRevalidate:O,revalidateOnlyGenerated:b,responseGenerator:l,waitUntil:r.waitUntil,isMinimalMode:K});if(!H)return null;if((null==d||null==(i=d.value)?void 0:i.kind)!==g.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(o=d.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",O?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),v&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,R.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&H||c.delete(E.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,T.getCacheControlHeader)(d.cacheControl)),await (0,p.sendResponse)(Y,G,new Response(d.value.body,{headers:c,status:d.value.status||200})),null};B&&j?await o(j):(n=q.getActiveScopeSpan(),await q.withPropagatedContext(e.headers,()=>q.trace(c.BaseServerSpan.handleRequest,{spanName:`${F} ${N}`,kind:i.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},o),void 0,!B))}catch(t){if(t instanceof A.NoFallbackError||await I.onRequestError(e,t,{routerKind:"App Router",routePath:M,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:V,isOnDemandRevalidate:O})},!1,x),H)throw t;return await (0,p.sendResponse)(Y,G,new Response(null,{status:500})),null}}e.s(["handler",0,x,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:S,workUnitAsyncStorage:v})},"routeModule",0,I,"serverHooks",0,w,"workAsyncStorage",0,S,"workUnitAsyncStorage",0,v],15523)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0n02tug._.js.map