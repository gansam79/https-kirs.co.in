var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__0c4bs7n._.js")
R.c("server/chunks/[root-of-the-server]__1ss5kys._.js")
R.c("server/chunks/1zb3_https-kirs_co_in__next-internal_server_app_robots_txt_route_actions_1-pksyw.js")
R.m(31479)
module.exports=R.m(31479).exports
