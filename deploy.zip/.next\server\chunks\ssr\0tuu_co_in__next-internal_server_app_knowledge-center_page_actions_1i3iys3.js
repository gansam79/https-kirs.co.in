module.exports=[94062,(a,b,c)=>{}];

//# sourceMappingURL=0tuu_co_in__next-internal_server_app_knowledge-center_page_actions_1i3iys3.js.map