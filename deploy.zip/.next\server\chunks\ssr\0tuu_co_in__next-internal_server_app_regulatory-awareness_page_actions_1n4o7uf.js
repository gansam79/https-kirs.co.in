module.exports=[49759,(a,b,c)=>{}];

//# sourceMappingURL=0tuu_co_in__next-internal_server_app_regulatory-awareness_page_actions_1n4o7uf.js.map