module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},38978,e=>{"use strict";var t=e.i(5075),a=e.i(69692),r=e.i(25147);let i=t.default.createPool({host:process.env.DB_HOST||"193.203.184.226",user:process.env.DB_USER||"u686584126_kirsdb",password:process.env.DB_PASSWORD||"Kirs@2026Db",database:process.env.DB_NAME||"u686584126_kirsdb",waitForConnections:!0,connectionLimit:10,queueLimit:0});async function n(e,t=[]){let[a]=await i.execute(e,t);return a}async function s(){try{await n(`
      CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);try{await n("ALTER TABLE contacts ADD COLUMN service VARCHAR(255) AFTER company;")}catch(e){}await n(`
      CREATE TABLE IF NOT EXISTS service_enquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        company VARCHAR(255),
        service VARCHAR(255),
        date VARCHAR(50),
        slot VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await n(`
      CREATE TABLE IF NOT EXISTS queries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(50) NOT NULL,
        name VARCHAR(255),
        email VARCHAR(255),
        phone VARCHAR(50),
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `),await n(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        rating INT NOT NULL,
        category VARCHAR(100) NOT NULL,
        comment TEXT NOT NULL,
        likes INT DEFAULT 0,
        status VARCHAR(50) DEFAULT 'approved',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let e=await n("SELECT COUNT(*) as count FROM reviews");if(0===e[0].count){for(let e of[{name:"Amitesh Sen",rating:5,category:"Verified Heir",comment:"Our family had 500 physical shares of Tata Motors from 1996. After my father passed, we had no idea how to demat them without a Will. KIRS drafted all succession bonds and guided us through court certification. Absolute experts!",likes:12},{name:"Dr. Rajesh Patel",rating:5,category:"Verified NRI Desk",comment:"I was living in New Jersey and trying to claim my deceased uncle's Reliance dividends from IEPF. The RTA rejected my documents twice due to spelling mismatches. The NRI desk at KIRS managed everything with embassy notarizations. Outstanding.",likes:9},{name:"Kavitha Sharma",rating:5,category:"Verified Owner",comment:"Highly professional work. My physical share certificate had signature differences from my bank account. They resolved the signature mismatch via Form ISR-2 updates and helped me convert everything to Demat in 2 months.",likes:8},{name:"Milind Deshpande",rating:5,category:"Verified Heir",comment:"We had a long-pending dispute regarding my late grandfather's bank deposits and physical mutual fund folios. KI&RS helped us clear the documentation roadblock under their success fee model. Extremely transparent and reliable team.",likes:15},{name:"Sunita Kulkarni",rating:5,category:"Verified Owner",comment:"Excellent guidance for unclaimed insurance policies. I had lost the original policy document of my husband. KIRS assisted in obtaining a duplicate policy and compiling the IEPF claim file. Highly recommended for Pune residents.",likes:6}])await n("INSERT INTO reviews (name, rating, category, comment, likes, status) VALUES (?, ?, ?, ?, ?, 'approved')",[e.name,e.rating,e.category,e.comment,e.likes]);console.log("Database initialized with seed review data.")}await n(`
      CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        short_desc TEXT,
        long_desc LONGTEXT,
        timeline VARCHAR(100),
        eligibility JSON,
        documents JSON,
        faqs JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let t=await n("SELECT COUNT(*) as count FROM services");if(0===t[0].count){for(let e of a.servicesData)await n(`INSERT INTO services (slug, title, short_desc, long_desc, timeline, eligibility, documents, faqs) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.shortDesc,e.longDesc,e.timeline,JSON.stringify(e.eligibility),JSON.stringify(e.documents),JSON.stringify(e.faqs)]);console.log("Database initialized with seed services data.")}await n(`
      CREATE TABLE IF NOT EXISTS blogs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(255) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        date VARCHAR(100),
        read_time VARCHAR(100),
        excerpt TEXT,
        content JSON,
        keywords JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);let i=await n("SELECT COUNT(*) as count FROM blogs");if(0===i[0].count){for(let e of r.blogData)await n(`INSERT INTO blogs (slug, title, category, date, read_time, excerpt, content, keywords) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[e.slug,e.title,e.category,e.date,e.readTime,e.excerpt,JSON.stringify(e.content),JSON.stringify(e.keywords)]);console.log("Database initialized with seed blog data.")}}catch(e){console.error("Database initialization failed:",e)}}e.s(["initializeDatabase",0,s,"query",0,n])},43383,e=>{"use strict";var t=e.i(16955),a=e.i(16208),r=e.i(18791),i=e.i(53535),n=e.i(95231),s=e.i(95054),o=e.i(87950),l=e.i(4341),d=e.i(62058),c=e.i(24346),u=e.i(76933),R=e.i(85277),p=e.i(44378),T=e.i(99537),E=e.i(62782),A=e.i(93695);e.i(59954);var m=e.i(83625),N=e.i(4279),h=e.i(38978);async function g(){try{await (0,h.initializeDatabase)();let e=await (0,h.query)("SELECT COUNT(*) as count FROM services"),t=await (0,h.query)("SELECT COUNT(*) as count FROM blogs"),a=await (0,h.query)("SELECT COUNT(*) as count FROM reviews"),r=await (0,h.query)("SELECT COUNT(*) as count FROM contacts");return N.NextResponse.json({success:!0,message:"Database tables created and initialized successfully!",stats:{services:e[0]?.count||0,blogs:t[0]?.count||0,reviews:a[0]?.count||0,contacts:r[0]?.count||0}})}catch(e){return console.error("API Init DB Error:",e),N.NextResponse.json({error:"Database initialization failed: "+(e.message||e)},{status:500})}}e.s(["GET",0,g],11033);var C=e.i(11033);let f=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/init-db/route",pathname:"/api/init-db",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/Data/AppData/App/ganesh/Personal/github/https-kirs.co.in/src/app/api/init-db/route.ts",nextConfigOutput:"",userland:C,...{}}),{workAsyncStorage:y,workUnitAsyncStorage:I,serverHooks:v}=f;async function S(e,t,r){r.requestMeta&&(0,i.setRequestMeta)(e,r.requestMeta),f.isDev&&(0,i.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let N="/api/init-db/route";N=N.replace(/\/index$/,"")||"/";let h=await f.prepare(e,t,{srcPage:N,multiZoneDraftMode:!1});if(!h)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:g,deploymentId:C,params:y,nextConfig:I,parsedUrl:v,isDraftMode:S,prerenderManifest:w,routerServerContext:O,isOnDemandRevalidate:x,revalidateOnlyGenerated:U,resolvedPathname:b,clientReferenceManifest:L,serverActionsManifest:M}=h,D=(0,o.normalizeAppPath)(N),H=!!(w.dynamicRoutes[D]||w.routes[b]),_=async()=>((null==O?void 0:O.render404)?await O.render404(e,t,v,!1):t.end("This page could not be found"),null);if(H&&!S){let e=!!w.routes[b],t=w.dynamicRoutes[D];if(t&&!1===t.fallback&&!e){if(I.adapterPath)return await _();throw new A.NoFallbackError}}let P=null;!H||f.isDev||S||(P="/index"===(P=b)?"/":P);let k=!0===f.isDev||!H,V=H&&!k;M&&L&&(0,s.setManifestsSingleton)({page:N,clientReferenceManifest:L,serverActionsManifest:M});let F=e.method||"GET",q=(0,n.getTracer)(),B=q.getActiveScopeSpan(),j=!!(null==O?void 0:O.isWrappedByNextServer),K=!!(0,i.getRequestMeta)(e,"minimalMode"),X=(0,i.getRequestMeta)(e,"incrementalCache")||await f.getIncrementalCache(e,I,w,K);null==X||X.resetRequestCache(),globalThis.__incrementalCache=X;let Y={params:y,previewProps:w.preview,renderOpts:{experimental:{authInterrupts:!!I.experimental.authInterrupts},cacheComponents:!!I.cacheComponents,supportsDynamicResponse:k,incrementalCache:X,cacheLifeProfiles:I.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r,i)=>f.onRequestError(e,t,r,i,O)},sharedContext:{buildId:g,deploymentId:C}},G=new l.NodeNextRequest(e),J=new l.NodeNextResponse(t),z=d.NextRequestAdapter.fromNodeNextRequest(G,(0,d.signalFromNodeResponse)(t));try{let i,s=async e=>f.handle(z,Y).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=q.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${F} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t),i&&i!==e&&(i.setAttribute("http.route",r),i.updateName(t))}else e.updateName(`${F} ${N}`)}),o=async i=>{var n,o;let l=async({previousCacheEntry:a})=>{try{if(!K&&x&&U&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let n=await s(i);e.fetchMetrics=Y.renderOpts.fetchMetrics;let o=Y.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let l=Y.renderOpts.collectedTags;if(!H)return await (0,R.sendResponse)(G,J,n,Y.renderOpts.pendingWaitUntil),null;{let e=await n.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(n.headers);l&&(t[E.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==Y.renderOpts.collectedRevalidate&&!(Y.renderOpts.collectedRevalidate>=E.INFINITE_CACHE)&&Y.renderOpts.collectedRevalidate,r=void 0===Y.renderOpts.collectedExpire||Y.renderOpts.collectedExpire>=E.INFINITE_CACHE?void 0:Y.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:n.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await f.onRequestError(e,t,{routerKind:"App Router",routePath:N,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:V,isOnDemandRevalidate:x})},!1,O),t}},d=await f.handleResponse({req:e,nextConfig:I,cacheKey:P,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:w,isRoutePPREnabled:!1,isOnDemandRevalidate:x,revalidateOnlyGenerated:U,responseGenerator:l,waitUntil:r.waitUntil,isMinimalMode:K});if(!H)return null;if((null==d||null==(n=d.value)?void 0:n.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(o=d.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",x?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),S&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,p.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&H||c.delete(E.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,T.getCacheControlHeader)(d.cacheControl)),await (0,R.sendResponse)(G,J,new Response(d.value.body,{headers:c,status:d.value.status||200})),null};j&&B?await o(B):(i=q.getActiveScopeSpan(),await q.withPropagatedContext(e.headers,()=>q.trace(c.BaseServerSpan.handleRequest,{spanName:`${F} ${N}`,kind:n.SpanKind.SERVER,attributes:{"http.method":F,"http.target":e.url}},o),void 0,!j))}catch(t){if(t instanceof A.NoFallbackError||await f.onRequestError(e,t,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:V,isOnDemandRevalidate:x})},!1,O),H)throw t;return await (0,R.sendResponse)(G,J,new Response(null,{status:500})),null}}e.s(["handler",0,S,"patchFetch",0,function(){return(0,r.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:I})},"routeModule",0,f,"serverHooks",0,v,"workAsyncStorage",0,y,"workUnitAsyncStorage",0,I],43383)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0cceyyc._.js.map