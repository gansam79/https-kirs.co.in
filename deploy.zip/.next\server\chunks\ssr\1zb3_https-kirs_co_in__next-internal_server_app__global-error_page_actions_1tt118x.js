module.exports=[25407,(a,b,c)=>{}];

//# sourceMappingURL=1zb3_https-kirs_co_in__next-internal_server_app__global-error_page_actions_1tt118x.js.map