var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[root-of-the-server]__0mgdyzq._.js")
R.c("server/chunks/07em_App_ganesh_Personal_github_https-kirs_co_in_src_data_servicesData_ts_0byghjg._.js")
R.c("server/chunks/[root-of-the-server]__1ss5kys._.js")
R.c("server/chunks/[root-of-the-server]__0v77pak._.js")
R.c("server/chunks/[root-of-the-server]__0-3_qrk._.js")
R.c("server/chunks/1zb3_https-kirs_co_in__next-internal_server_app_api_contact_route_actions_1emdj8c.js")
R.m(8692)
module.exports=R.m(8692).exports
