var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[externals]__1i1qxq_._.js")
R.c("server/chunks/[root-of-the-server]__0-3_qrk._.js")
R.c("server/chunks/[root-of-the-server]__04cf3rp._.js")
R.c("server/chunks/[root-of-the-server]__1ss5kys._.js")
R.c("server/chunks/1zb3_https-kirs_co_in__next-internal_server_app_api_contact_route_actions_1emdj8c.js")
R.m(8692)
module.exports=R.m(8692).exports
